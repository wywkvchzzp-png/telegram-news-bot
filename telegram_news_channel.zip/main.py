import os
import json
import hashlib
import html
import logging
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import requests
import feedparser

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

BOT_TOKEN = os.environ["BOT_TOKEN"].strip()
CHANNEL_ID = os.environ["CHANNEL_ID"].strip()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
STATE_FILE = "posted_ids.json"

FEEDS = [
    "https://news.google.com/rss?hl=ru&gl=RU&ceid=RU:ru",
    "https://feeds.bbci.co.uk/news/world/rss.xml",
    "https://www.theguardian.com/world/rss",
]

def load_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return set(data if isinstance(data, list) else [])
    except (FileNotFoundError, json.JSONDecodeError):
        return set()

def save_state(ids):
    # Keep the latest 1,000 identifiers so the state file stays small.
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(list(ids)[-1000:], f, ensure_ascii=False, indent=2)

def get_items():
    items = []
    for url in FEEDS:
        try:
            response = requests.get(url, timeout=20, headers={"User-Agent": "NewsChannelBot/1.0"})
            response.raise_for_status()
            feed = feedparser.parse(response.content)
            for entry in feed.entries[:30]:
                title = (entry.get("title") or "").strip()
                link = (entry.get("link") or "").strip()
                summary = (entry.get("summary") or entry.get("description") or "").strip()
                published = entry.get("published", "")
                if not title or not link:
                    continue
                uid = hashlib.sha256(link.encode("utf-8")).hexdigest()
                items.append({
                    "id": uid, "title": title, "link": link,
                    "summary": summary, "published": published,
                    "source": feed.feed.get("title", "Источник")
                })
        except Exception as e:
            logging.warning("RSS error for %s: %s", url, e)
    # Prefer newest items; if dates are missing, retain feed order.
    def sort_key(item):
        try:
            dt = parsedate_to_datetime(item["published"])
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except Exception:
            return 0
    items.sort(key=sort_key, reverse=True)
    return items

def ai_rewrite(item):
    if not GEMINI_API_KEY:
        return None
    prompt = (
        "Ты редактор русскоязычного Telegram-канала с популярными новостями. "
        "По заголовку и краткому описанию ниже составь на русском короткий пересказ "
        "в 2-3 предложениях, без выдуманных фактов, оценок и неподтверждённых деталей. "
        "Не повторяй заголовок дословно. Если данных мало, осторожно перескажи только то, "
        "что известно. Верни только текст поста, без хэштегов и без ссылки.\n\n"
        f"Заголовок: {item['title']}\nОписание: {item['summary'][:2500]}"
    )
    endpoint = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        "gemini-2.5-flash-lite:generateContent?key=" + GEMINI_API_KEY
    )
    payload = {"contents": [{"parts": [{"text": prompt}]}],
               "generationConfig": {"temperature": 0.3, "maxOutputTokens": 180}}
    try:
        r = requests.post(endpoint, json=payload, timeout=30)
        r.raise_for_status()
        data = r.json()
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        logging.warning("Gemini failed; using RSS summary: %s", e)
        return None

def fallback_summary(item):
    # A simple no-API fallback: use the feed's description if available.
    text = item["summary"]
    if not text:
        return "Читайте подробности в первоисточнике по ссылке ниже."
    text = html.unescape(text)
    # Strip basic HTML tags without adding a dependency.
    import re
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > 500:
        text = text[:497].rsplit(" ", 1)[0] + "…"
    return text or "Читайте подробности в первоисточнике по ссылке ниже."

def telegram_send(text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    r = requests.post(url, json={
        "chat_id": CHANNEL_ID,
        "text": text,
        "disable_web_page_preview": False
    }, timeout=25)
    r.raise_for_status()
    data = r.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram API error: {data}")
    return data

def main():
    posted = load_state()
    items = get_items()
    fresh = [item for item in items if item["id"] not in posted]
    if not fresh:
        logging.info("No new stories found.")
        return

    # Publish one new story per run to avoid flooding the channel.
    item = fresh[0]
    body = ai_rewrite(item) or fallback_summary(item)
    title = html.escape(item["title"])
    body = html.escape(body)
    source_url = html.escape(item["link"], quote=True)
    post = f"📰 <b>{title}</b>\n\n{body}\n\n🔗 <a href=\"{source_url}\">Источник</a>\n\n#Новости"
    # Use HTML formatting for reliable bold title and source link.
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    response = requests.post(url, json={
        "chat_id": CHANNEL_ID,
        "text": post,
        "parse_mode": "HTML",
        "disable_web_page_preview": False
    }, timeout=25)
    response.raise_for_status()
    result = response.json()
    if not result.get("ok"):
        raise RuntimeError(f"Telegram API error: {result}")

    posted.add(item["id"])
    save_state(posted)
    logging.info("Published: %s", item["title"])

if __name__ == "__main__":
    main()
